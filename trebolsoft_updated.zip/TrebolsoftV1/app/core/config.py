from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    APP_ENV: str = "local"
    APP_NAME: str = "TrebolSoft API"
    APP_PORT: int = 8000
    APP_DOMAIN: str = "trebolsoft.com"
    API_DOMAIN: str = "api.trebolsoft.com"

    DATABASE_URL: str
    CORS_ALLOWED_ORIGINS: str | None = None  # CSV

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

settings = Settings()
