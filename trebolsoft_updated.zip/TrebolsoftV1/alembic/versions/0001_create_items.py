from alembic import op
import sqlalchemy as sa

revision = '0001_create_items'
down_revision = None
branch_labels = None
depends_on = None

def upgrade() -> None:
    op.create_table(
        'items',
        sa.Column('id', sa.Integer(), primary_key=True, nullable=False),
        sa.Column('name', sa.String(length=100), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
    )
    op.create_index('ix_items_id', 'items', ['id'], unique=False)
    op.create_index('ix_items_name', 'items', ['name'], unique=False)

def downgrade() -> None:
    op.drop_index('ix_items_name', table_name='items')
    op.drop_index('ix_items_id', table_name='items')
    op.drop_table('items')
